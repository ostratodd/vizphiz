predict_wavelen <-
function (model, fasta_file) 
{
    fasta <- load_fasta_data(fasta_file, model$position)
    X <- fasta$seq.bin[, -model$removed_feat]
    predict(model$model, newdata = cbind(1, X))
}
