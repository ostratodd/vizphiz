train_glasso <-
function (fasta_file, wavelength_file, pos_file = NULL) 
{
    set.seed(1)
    standardize = F
    nfold <- 10
    length_lam <- 10
    gamma <- 0.5^seq(0, 8, length.out = length_lam)
    if (!is.null(pos_file)) {
        position <- as.matrix(read.table(pos_file))
    }
    else {
        position <- NULL
    }
    fasta <- load_fasta_data(fasta_file, position)
    X <- fasta$seq.bin
    wavelength <- as.matrix(read.table(wavelength_file))
    Y = wavelength
    missing_idx <- which(is.na(Y))
    symbols_to_rm <- c("-", "*", "x")
    removed_feat <- which(is.element(colnames(X), symbols_to_rm))
    test_X <- X[missing_idx, ]
    X <- X[-missing_idx, ]
    Y <- Y[-missing_idx]
    amino_seq <- fasta$fasta_full_seq[-missing_idx, ]
    X <- X[, -removed_feat]
    test_X <- test_X[, -removed_feat]
    amino_names <- fasta$amino.names[-na.omit(match(symbols_to_rm, 
        fasta$amino.names))]
    seq_len <- fasta$seq.len
    grp_idx <- c(NA, as.vector(outer(rep(1, length(amino_names)), 
        1:seq_len)))
    n <- length(Y)
    glasso <- grplasso_path(X, Y, gamma, nfold, grp_idx, standardize, 
        1)
    predicted_wavelen <- predict(glasso, newdata = cbind(1, test_X))
    list(model = glasso, position = position, predicted_wavelen = predicted_wavelen, 
        test_idx = missing_idx, wavelength = wavelength, removed_feat = removed_feat)
}
