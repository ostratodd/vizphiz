grplasso_path <-
function (X, Y, gamma, nfold, grp_idx, standardize, ncore = 1) 
{
    foldid <- sample(length(Y))%%nfold + 1
    X_temp <- X
    X_temp[, colSums(X_temp > 0) == nrow(X_temp)] <- 0
    lambda <- lambdamax(x = cbind(1, X_temp), y = Y, index = grp_idx, 
        penscale = sqrt, model = LinReg(), center = F, standardize = standardize) * 
        gamma
    parallel <- (ncore > 1)
    doop <- ifelse(parallel, `%dopar%`, `%do%`)
    if (parallel) {
        library(doSNOW)
        cl <- makeCluster(ncore, type = "SOCK")
        registerDoSNOW(cl)
    }
    vars <- ls()
    E.all <- doop(foreach(k = 1:nfold, .export = vars, .packages = c("grplasso")), 
        {
            cat("fold =", k, "\n")
            X_temp <- X[foldid != k, ]
            X_temp[, colSums(X_temp > 0) == nrow(X_temp)] <- 0
            res.grp <- grplasso(x = cbind(1, X_temp), y = Y[foldid != 
                k], index = grp_idx, model = LinReg(), lambda = lambda, 
                center = F, standardize = standardize)
            Yval <- predict(res.grp, newdata = cbind(1, X[foldid == 
                k, ]))
            list(Ecv = colSums((Yval - outer(Y[foldid == k], 
                rep(1, ncol(Yval))))^2))
        })
    if (parallel) {
        stopCluster(cl)
    }
    Ecv <- sqrt(rowSums(sapply(E.all, function(e) {
        e$Ecv
    }))/length(Y)/length(Y))
    min.idx <- which.min(Ecv)
    print(min.idx)
    print(lambda[min.idx])
    X_temp <- X
    X_temp[, colSums(X_temp > 0) == nrow(X_temp)] <- 0
    res.grp.cv <- grplasso(x = cbind(1, X_temp), y = Y, index = grp_idx, 
        lambda = lambda[min.idx], standardize = standardize, 
        model = LinReg(), center = F)
    res.grp.cv
}
