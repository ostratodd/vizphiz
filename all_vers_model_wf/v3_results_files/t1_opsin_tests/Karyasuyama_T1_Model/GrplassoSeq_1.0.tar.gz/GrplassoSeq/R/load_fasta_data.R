load_fasta_data <-
function (fasta_file, position = NULL) 
{
    fasta_raw_data <- read.fasta(fasta_file)
    fasta.seq <- t(sapply(fasta_raw_data, function(s) {
        s
    }))
    position_in_aligned_seq <- NULL
    fasta_full_seq <- fasta.seq
    if (!is.null(position)) {
        fasta.seq <- fasta.seq[, position]
    }
    binary.data.concat <- model.matrix(~. + 0, data = data.frame(factor(fasta.seq)))
    colnames(binary.data.concat) <- sub("factor.fasta.seq.", 
        "", colnames(binary.data.concat))
    amino.names <- colnames(binary.data.concat)
    poswise.amino.list <- (lapply(1:ncol(fasta.seq), function(i) {
        (binary.data.concat[((i - 1) * nrow(fasta.seq) + 1):(i * 
            nrow(fasta.seq)), ])
    }))
    seq.bin <- do.call("cbind", poswise.amino.list)
    seq.len <- ncol(fasta.seq)
    list(fasta = fasta_raw_data, fasta_full_seq = fasta_full_seq, 
        position_in_aligned_seq = position_in_aligned_seq, fasta.seq = fasta.seq, 
        amino.names = amino.names, seq.bin = seq.bin, seq.len = seq.len)
}
